#include <stdio.h>

// Variable neighborhood search
#define DISTANCE_MIN                1
#define DISTANCE_MAX_LOW          0.1
#define DISTANCE_MAX_HIGH         0.4
#define DISTANCE_STEP_COEF         50
#define REJECT_THRESHOLD            5

// Simulated annealing
#define COOLING_FACTOR           0.95
#define MIN_TEMPERATURE        0.0001
#define TEMPERATURE_COEF1         100
#define TEMPERATURE_COEF2          10
#define SIZE_THRESHOLD           5000
#define SAMPLE_SIZE              5000
#define SA_TIME_QUOTA             0.5

#define ST_COUNT                   20

#define ALS(X,Y,Z) if ((X=(Y *)calloc(Z,sizeof(Y)))==NULL) \
       {fprintf(out,"  failure in memory allocation\n");exit(0);}
#define ALI(X,Z) if ((X=(int *)calloc(Z,sizeof(int)))==NULL) \
       {fprintf(out,"  failure in memory allocation\n");exit(0);}

#define gr(X,Y) *((pinst+X)->gr+Y)
#define edge(X,Y) *((pinst+X)->edge+Y)
#define a(X,Y) *((pinst+X)->a+Y)
#define b(X,Y) *((pinst+X)->b+Y)
#define d(X,Y) *((pinst+X)->d+Y)
#define sol(Y) *(pres->sol+Y)


typedef struct
     {int *gr;        /*  */
      int *edge;      /*  */
      int *a;         /*  */
      int *b;         /*  */
      int *d;         /*  */
     }Instance;

typedef struct
     {int p;          /*  */
      int bp;         /*  */
      int pi;         /*  */
      int h;          /*  */
      int aln;        /*  */
      int bln;        /*  */
      int dln;        /*  */
      int a;          /*  */
      int ve;         /*  */
      int av;         /*  */
      int deg;        /*  */
      int h2;         /*  */
      int y;          /*  */
      int z;          /*  */
      int s1;         /*  */
      int s2;         /*  */
      int s3;         /*  */
      int s3a;        /*  */
      int s4;         /*  */
      long perf;      /*  */
     }Solution;

typedef struct
     {int *sol;             /* solution obtained                    */
      long value;           /* solution value                       */
      double total_time;    /* total time, secs                     */
      double time_to_best;  /* time to the best solution, secs      */
      int characts[10];     /* some characteristics:                */
                            /*    characts[0] - number of vertices  */
     }Results;
