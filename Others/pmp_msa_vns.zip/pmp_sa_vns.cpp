/* Program: An implementation of the variable neighborhood search (VNS)
         and multi-start simulated annealing (MSA) hybrid for the profile 
         minimization problem (PMP):
         Find an ordering of the vertices of a given graph such that the sum 
         of the profiles of all its vertices is minimized. The profile of the 
         vertex v in position i is defined as the difference i-f(v) where 
         f(v) is the position of the leftmost vertex among all vertices placed 
         to the left of v and adjacent to v (if no such vertex exists, then 
         f(v)=i, that is, profile of v is zero). 
   Author: Gintaras Palubeckis
   Date: 2016-06-11
   Language: C++
   Some of the input data are supplied through the parameters and the rest 
     through the (input) file. An instance of the PMP in this file is 
     represented by the list of edges of the graph and, possibly, their weights. 
     The program terminates when a specified time limit is reached.
   Parameters:
     - input file name;
     - output file name;
     - seed for random number generator;
     - time limit (in seconds);
     - a pointer to structure 'Results' for writing down the solution found 
       and the performance characteristics. The structure is defined in 
       file 'pmp_sa_vns.h'. It is possible to have the last parameter null: 
       in this case, information is directed only to the output file.
   Examples of invocation:
       either
     Results *pres;
     char in_file_name[80],out_file_name[80];
     double seed=5000;
     pres=(Results *)calloc(1,sizeof(Results));
     strcpy(in_file_name,"D:\\data\\can__187.mtx");
     strcpy(out_file_name,"D:\\temp\\can__187.res");
     pmp_sa_vns(in_file_name,out_file_name,seed,20,pres);
       or just
     char in_file_name[80],out_file_name[80];
     double seed=5000;
     strcpy(in_file_name,"D:\\data\\can__187.mtx");
     strcpy(out_file_name,"D:\\temp\\can__187.res");
     pmp_sa_vns(in_file_name,out_file_name,seed,20,NULL);
   Input file contains:
     - the number of vertices;
     - the number of edges;
     - either the edges represented by their endvertices 
       or the edges plus their weights (which are ignored in the PMP). 
   Example of the input file:
187 839 
1 1
2 1
32 1
33 1
34 1
64 1
2 2
3 2
33 2
34 2
35 2
3 3
4 3
34 3
35 3
36 3
4 4
5 4
35 4
...
...
...
   Another example of the input file:
153 1288
1 1  3.1431392791300e+05
4 1 -8.6857870528200e+04
5 1  5.6340240342600e+04
7 1 -3.5149546714100e+04
8 1  9.3732124570800e+04
9 1 -3.5149546714100e+04
10 1 -3.5149546714100e+04
11 1 -9.3732124570800e+04
12 1  3.5149546714100e+04
13 1 -8.6857870528200e+04
14 1 -5.6340240342600e+04
16 1 -3.5149546714100e+04
17 1 -9.3732124570800e+04
18 1 -3.5149546714100e+04
19 1 -3.5149546714100e+04
20 1  9.3732124570800e+04
21 1  3.5149546714100e+04
2 2  1.0728993702800e+06
3 2  4.6566128730800e-10
4 2  5.6340240342600e+04
5 2 -3.6545020762800e+04
7 2  9.3732124570800e+04
8 2 -2.4995233218900e+05
9 2  9.3732124570800e+04
10 2 -9.3732124570800e+04
11 2 -2.4995233218900e+05
12 2  9.3732124570800e+04
13 2 -5.6340240342600e+04
14 2 -3.6545020762800e+04
16 2 -9.3732124570800e+04
17 2 -2.4995233218900e+05
18 2 -9.3732124570800e+04
19 2  9.3732124570800e+04
20 2 -2.4995233218900e+05
21 2 -9.3732124570800e+04
3 3  1.4059818685600e+05
7 3 -3.5149546714100e+04
8 3  9.3732124570800e+04
...
...
...
*/



#include <alloc.h>
#include <process.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "pmp_sa_vns.h"



 double random(double *seed,double coef)
 {double rd,rf;
  rd=16807*(*seed);rf=floor(rd/coef);
  *seed=rd-rf*coef;
  return(*seed/(coef+1));
 }


 double take_time(int *time_values,clock_t start)
 {int i;
  int hours,mins;
  long longsecs;
  double elapsed_sec;
  clock_t end;
  end=clock();
  elapsed_sec=(end-start)/CLK_TCK;
  longsecs=elapsed_sec;
  for (i=1;i<=4;i++) time_values[i]=0;
  hours=(int)(longsecs/3600);
  if (hours>0)     /* more than an hour  */
     {time_values[1]=hours;longsecs-=hours*3600;}
  mins=(int)(longsecs/60);
  if (mins>0)     /* more than a minute */
     {time_values[2]=mins;longsecs-=mins*60;}
  time_values[3]=(int)longsecs;
  time_values[4]=elapsed_sec*1000-(long)elapsed_sec*1000;
  return elapsed_sec;
 }


 long get_best_value(int n,int ec,Instance *pinst,Solution *psol)
 {int i,k,l,m;
  int r,s,u;
  long sol_val=0;
// Calculation of the value of the best solution
  for (m=1;m<=n;m++) (psol+(psol+m)->bp)->pi=m;
  for (u=1;u<=n;u++) (psol+u)->h2=(psol+u)->pi;
  for (i=1;i<=ec;i++)
     {r=edge(0,i);k=(psol+r)->pi;
      s=edge(1,i);l=(psol+s)->pi;
      if (k<l) {if (k<(psol+s)->h2) (psol+s)->h2=k;}
       else if (l<(psol+r)->h2) (psol+r)->h2=l;
     }
  for (u=1;u<=n;u++)
     {if ((psol+u)->h2==(psol+u)->pi) continue;
      sol_val+=((psol+u)->pi-(psol+u)->h2);
     }
  return sol_val;
 }


 void random_start(int n,double coef,double *seed,Solution *psol)
 {int i,k;
  int r;
// Randomly generating permutation
  for (i=1;i<=n;i++) (psol+i)->a=i;
  for (i=1;i<=n;i++)
     {k=random(seed,coef)*(n-i+1);k+=i;
      r=(psol+k)->a;(psol+i)->p=r;(psol+r)->pi=i;
      (psol+k)->a=(psol+i)->a;
     }
 }


 long init_data(int n,int ec,Instance *pinst,Solution *psol)
 {int i,k,l;
  int r,s,u;
  long sol_val=0;

  for (u=1;u<=n;u++)
     {(psol+u)->aln=0;
      (psol+u)->h=(psol+u)->pi;
     }
  for (i=1;i<=ec;i++)
     {r=edge(0,i);k=(psol+r)->pi;
      s=edge(1,i);l=(psol+s)->pi;
      if (k<l) {if (k<(psol+s)->h) {(psol+s)->h=k;(psol+s)->ve=r;}}
       else if (l<(psol+r)->h) {(psol+r)->h=l;(psol+r)->ve=s;}
     }
  for (u=1;u<=n;u++)
     {if ((psol+u)->h==(psol+u)->pi) continue;
      r=(psol+u)->ve;((psol+r)->aln)++;a(r,(psol+r)->aln)=u;
      sol_val+=((psol+u)->pi-(psol+u)->h);
     }
  return sol_val;
 }


 int get_gain(int n,int r,int s,int k,int l,Instance *pinst,Solution *psol)
 {int i,j,q,t;
  int v,u;
  int dif=0;
  int lmost;
  int c1=0,c2=0,c3=0,c4=0;

// Permutation interval between swapped vertices (exclusively) is processed
  for (q=k+1;q<l;q++)
     {v=(psol+q)->p;
      for (i=1;i<=(psol+v)->aln;i++)
         {u=a(v,i);
          if (u!=s && gr(u,s)>0) {dif+=(q-k);c1++;(psol+c1)->s1=u;}
         }
      if (gr(v,s)>0 && (psol+v)->h==q) {dif+=(q-k);c1++;(psol+c1)->s1=v;}
     }
// Operations for the right vertex in the pair
  for (i=1;i<=(psol+s)->aln;i++) {dif+=(l-k);c2++;(psol+c2)->s2=a(s,i);}
  if ((psol+s)->h>=k) {dif-=(l-(psol+s)->h);psol->a=(psol+(psol+s)->h)->p;}
   else {dif-=(l-k);psol->a=0;}
// Considering vertices for which the left vertex of the pair is the leftmost adjacent one 
  for (i=1;i<=(psol+r)->aln;i++)
     {u=a(r,i);if (u==s) continue;
      if (gr(u,s)>0) {c1++;(psol+c1)->s1=u;continue;}
      lmost=n;q=(psol+u)->pi;
      for (j=1;j<=(psol+u)->dln;j++)
         {t=(psol+d(u,j))->pi;
          if (t<=k || t>=q) continue;
          if (t<lmost) {lmost=t;v=d(u,j);}
         }
      if (lmost==n)
         {if (q>l) {dif-=(l-k);c4++;(psol+c4)->s4=u;}
           else {dif-=(q-k);c3++;(psol+c3)->s3=u;(psol+c3)->s3a=u;}
         }
       else if (lmost<l) {dif-=(lmost-k);c3++;(psol+c3)->s3=u;(psol+c3)->s3a=v;}
        else if (lmost==l) {c1++;(psol+c1)->s1=u;}
         else {dif-=(l-k);c4++;(psol+c4)->s4=u;}
     }
// Operations for the left vertex in the pair itself
  if ((psol+r)->h<k) {dif+=(l-k);psol->ve=0;}
   else
     {lmost=n;
      for (j=1;j<=(psol+r)->dln;j++)
         {t=(psol+d(r,j))->pi;
          if (t>l) continue;
          if (t==l) {lmost=k;v=d(r,j);}
          if (t<lmost) {lmost=t;v=d(r,j);}
         }
      if (lmost==n) psol->ve=-1;
       else if (lmost==k) {dif+=(l-k);psol->ve=s;}
        else {dif+=(l-lmost);psol->ve=v;}
     }
// Saving lengths of arrays (for possible interchange) 
  psol->s1=c1;psol->s2=c2;psol->s3=c3;psol->s4=c4;
  return dif;
 }


 void perform_interchange(int r,int s,int k,int l,Instance *pinst,Solution *psol)
 {int i,q,t;
  int v,u;

// Processing array "s1"
  for (q=1;q<=psol->s1;q++)
     {v=(psol+q)->s1;u=(psol+(psol+v)->h)->p;
      if (u!=v)
         {for (i=1;i<=(psol+u)->aln;i++) if (a(u,i)==v) {t=i;break;}
          a(u,t)=a(u,(psol+u)->aln);((psol+u)->aln)--;
         }
      ((psol+s)->aln)++;a(s,(psol+s)->aln)=v;
      (psol+v)->h=k;
     }
// Processing array "s2"
  for (q=1;q<=psol->s2;q++) (psol+(psol+q)->s2)->h=k;
// Processing array "s3"
  for (q=1;q<=psol->s3;q++)
     {v=(psol+q)->s3;u=(psol+q)->s3a;
      for (i=1;i<=(psol+r)->aln;i++) if (a(r,i)==v) {t=i;break;}
      a(r,t)=a(r,(psol+r)->aln);((psol+r)->aln)--;
      if (v!=u) {((psol+u)->aln)++;a(u,(psol+u)->aln)=v;}
      (psol+v)->h=(psol+u)->pi;
     }
// Processing array "s4"
  for (q=1;q<=psol->s4;q++) (psol+(psol+q)->s4)->h=l;
// Considering right vertex in the pair
  if (psol->a==s) (psol+s)->h=k;
   else if (psol->a>0) 
     {v=psol->a;
      for (i=1;i<=(psol+v)->aln;i++) if (a(v,i)==s) {t=i;break;}
      a(v,t)=a(v,(psol+v)->aln);((psol+v)->aln)--;
      (psol+s)->h=k;
     }
// Considering left vertex in the pair
  if (psol->ve<0) (psol+r)->h=l;
   else if (psol->ve>0) 
     {v=psol->ve;
      ((psol+v)->aln)++;a(v,(psol+v)->aln)=r;
      if (v==s) (psol+r)->h=k; else (psol+r)->h=(psol+v)->pi;
     }
// Exchanging positions of the selected facilities
  (psol+k)->p=s;(psol+l)->p=r;
  (psol+r)->pi=l;(psol+s)->pi=k;
 }


 int init_temperature(int n,int sam_size,double coef,double *seed,Instance *pinst,
      Solution *psol)
 {int i,j,k,l;
  int r,s;
  int t_max=-1,dif;

  for (j=1;j<=sam_size;j++)
     {r=random(seed,coef)*n;if (r<n) r++;k=(psol+r)->pi;
      s=r;
      while (s==r) {s=random(seed,coef)*n;if (s<n) s++;}
      l=(psol+s)->pi;
      if (l<k) {i=k;k=l;l=i;i=r;r=s;s=i;}
      dif=get_gain(n,r,s,k,l,pinst,psol);
      if (dif<0) dif=-dif;
      if (dif>t_max) t_max=dif;
     }
  return t_max;
 }


 void store_new_best_sol(int n,int st,int *time_values_opt,
      double *time_to_opt,clock_t start_time,Solution *psol)
 {int k;
  for (k=1;k<=n;k++) (psol+k)->bp=(psol+k)->p;
  ((psol+1)->perf)++;(psol+2)->perf=st;
  *time_to_opt=take_time(time_values_opt,start_time);
 }


 long sa(int n,int ec,int tred,int tlength,long best_value,long st,
      double time_limit_sa,double t_max,double coef,int *stop_cond,
      int *time_values_opt,double *time_to_opt,double *seed1,double *seed2,
      clock_t start_time,Instance *pinst,Solution *psol)
 {int i,k,l,r,s;
  int tr,tl;
  int accept;
  int dif;
  long sol_value;
  double elapsed_time;
  double t;
  double c_factor;
  double db,md;
  clock_t end_time;

  if (st==1) sol_value=best_value;
   else
     {random_start(n,coef,seed1,psol);
      sol_value=init_data(n,ec,pinst,psol);
     }
  c_factor=COOLING_FACTOR;
  t=t_max;
// Simulated annealing ...
  for (tr=1;tr<=tred;tr++)
     {for (tl=1;tl<=tlength;tl++)
// Selecting a pair of vertices at random 
         {r=random(seed2,coef)*n;if (r<n) r++;
          s=r;
          while (s==r) {s=random(seed2,coef)*n;if (s<n) s++;}
          k=(psol+r)->pi;l=(psol+s)->pi;
          if (k>l) {i=r;r=s;s=i;i=k;k=l;l=i;}
// Getting the gain value 
          dif=get_gain(n,r,s,k,l,pinst,psol);
          if (dif<=0) accept=2;
           else
             {md=random(seed2,coef);
              db=-dif/t;db=exp(db);
              if (md<=db) accept=1; else accept=0;
             }
          if (accept==0) continue;
// Performing interchange move
          sol_value+=dif;
          perform_interchange(r,s,k,l,pinst,psol);
          if (accept<2) continue;
          if (sol_value<best_value)
             {best_value=sol_value;
              store_new_best_sol(n,st,time_values_opt,time_to_opt,start_time,psol);
             }
         }
      end_time=clock();
      elapsed_time=(end_time-start_time)/CLK_TCK;
      if (elapsed_time>=time_limit_sa) {*stop_cond=1; break;}
      t=c_factor*t;
     }
  for (i=1;i<=n;i++) {(psol+i)->p=(psol+i)->bp;(psol+(psol+i)->p)->pi=i;}
  return best_value;
 }


 long msa(int n,int ec,double time_limit_sa,double coef,
      int *time_values_opt,double *time_to_opt,double *seed1,
      clock_t start_time,Instance *pinst,Solution *psol)
 {int stop_cond=0;
  int tred;
  int tlength;
  long st=0;
  long best_value;
  double t_max;
  double seed2;

  seed2=2*(*seed1);
  (psol+1)->perf=-1;

  random_start(n,coef,seed1,psol);
  best_value=init_data(n,ec,pinst,psol);
  store_new_best_sol(n,-1,time_values_opt,time_to_opt,start_time,psol);
// Preparing SA parameters
  t_max=init_temperature(n,SAMPLE_SIZE,coef,seed1,pinst,psol);
  if (t_max==0) return best_value;
  tred=(log(MIN_TEMPERATURE)-log(t_max))/log(COOLING_FACTOR);(psol+11)->perf=tred;
  if (n<=SIZE_THRESHOLD) tlength=TEMPERATURE_COEF1*n; else tlength=TEMPERATURE_COEF2*n;
  (psol+12)->perf=tlength;
// Multi-start simulated annealing ...
  while (stop_cond==0)
     {st++;
      best_value=sa(n,ec,tred,tlength,best_value,st,time_limit_sa,
          t_max,coef,&stop_cond,time_values_opt,time_to_opt,
          seed1,&seed2,start_time,pinst,psol);
     }
// Storing the total number of simulated annealing restarts executed
  (psol+13)->perf=st;
  (psol+14)->perf=(psol+1)->perf;
  (psol+15)->perf=(psol+2)->perf;
  return best_value;
 }


 void prepare_data(int n,int ec,Instance *pinst,Solution *psol)
 {int i;
  int r,s;
// Initializing "y" and "z" arrays with zeros
  for (i=1;i<=n;i++)
     {(psol+i)->dln=0;
      (psol+i)->y=0;(psol+i)->z=0;
     }
// Neighbors of each vertex are stored in the corresponding row of 2-dimensional array "d"
  for (i=1;i<=ec;i++)
     {r=edge(0,i);s=edge(1,i);
      ((psol+r)->dln)++;d(r,(psol+r)->dln)=s;
      ((psol+s)->dln)++;d(s,(psol+s)->dln)=r;
     }
 }


 long init_insertions(int n,int ec,Instance *pinst,Solution *psol)
 {int i,k,l;
  int r,s,u;
  long sol_val=0;

  for (u=1;u<=n;u++)
     {(psol+u)->aln=0;(psol+u)->bln=0;
      (psol+u)->h=(psol+u)->pi;
     }
  for (i=1;i<=ec;i++)
     {r=edge(0,i);k=(psol+r)->pi;
      s=edge(1,i);l=(psol+s)->pi;
      if (k<l)
         {((psol+s)->bln)++;b(s,(psol+s)->bln)=r;
          if (k<(psol+s)->h) {(psol+s)->h=k;(psol+s)->ve=r;}
         }
       else
         {((psol+r)->bln)++;b(r,(psol+r)->bln)=s;
          if (l<(psol+r)->h) {(psol+r)->h=l;(psol+r)->ve=s;}
         }
     }
  for (u=1;u<=n;u++)
     {if ((psol+u)->h==(psol+u)->pi) continue;
      r=(psol+u)->ve;((psol+r)->aln)++;a(r,(psol+r)->aln)=u;
      sol_val+=((psol+u)->pi-(psol+u)->h);
     }
  return sol_val;
 }


 void perform_insertion(int n,int r,int l,Instance *pinst,Solution *psol)
 {int i,j,k,m,q,t;
  int s,u,z;
  int lmost;

// Performing insertion
  k=(psol+r)->pi;
  if (l<k)
     {for (m=k;m>l;m--)
         {u=(psol+m-1)->p;
          (psol+m)->p=u;(psol+u)->pi=m;
         }
     }
   else
     {for (m=k;m<l;m++)
         {u=(psol+m+1)->p;
          (psol+m)->p=u;(psol+u)->pi=m;
         }
     }
  (psol+l)->p=r;(psol+r)->pi=l;
// Updating data
// The case of inserting to the left
  if (l<k)
     {for (j=l+1;j<=k;j++)
         {s=(psol+j)->p;
          if (gr(r,s)>0) 
             {for (i=1;i<=(psol+r)->bln;i++) if (b(r,i)==s) {q=i;break;}
              b(r,q)=b(r,(psol+r)->bln);((psol+r)->bln)--;
              ((psol+s)->bln)++;b(s,(psol+s)->bln)=r;
              if ((psol+r)->h==j-1)
                 {for (i=1;i<=(psol+s)->aln;i++) if (a(s,i)==r) {q=i;break;}
                  a(s,q)=a(s,(psol+s)->aln);((psol+s)->aln)--;
                 }
             }
          if ((psol+s)->h<l) continue;
          if (gr(r,s)>0) 
             {if ((psol+s)->h+1<j)
                 {u=(psol+(psol+s)->h+1)->p;
                  for (i=1;i<=(psol+u)->aln;i++) if (a(u,i)==s) {q=i;break;}
                  a(u,q)=a(u,(psol+u)->aln);((psol+u)->aln)--;
                 }
              ((psol+r)->aln)++;a(r,(psol+r)->aln)=s;
              (psol+s)->h=l;
             }
            else ((psol+s)->h)++;
         }
      for (j=k+1;j<=n;j++)
         {s=(psol+j)->p;
          if ((psol+s)->h==k) {(psol+s)->h=l;continue;}
          if ((psol+s)->h<l) continue;
          if (gr(r,s)>0) 
             {u=(psol+(psol+s)->h+1)->p;
              for (i=1;i<=(psol+u)->aln;i++) if (a(u,i)==s) {q=i;break;}
              a(u,q)=a(u,(psol+u)->aln);((psol+u)->aln)--;
              ((psol+r)->aln)++;a(r,(psol+r)->aln)=s;
              (psol+s)->h=l;
             }
            else if ((psol+s)->h<k) ((psol+s)->h)++;
         }
      if ((psol+r)->h>l) (psol+r)->h=l;
     }
   else
// The case of inserting to the right
     {for (j=k;j<=n;j++)
         {if (j==l) continue;
          s=(psol+j)->p;
          if (j<l && gr(r,s)>0) 
             {for (i=1;i<=(psol+s)->bln;i++) if (b(s,i)==r) {q=i;break;}
              b(s,q)=b(s,(psol+s)->bln);((psol+s)->bln)--;
              ((psol+r)->bln)++;b(r,(psol+r)->bln)=s;
             } 
          if ((psol+s)->h!=k) 
             {if (k<(psol+s)->h && (psol+s)->h<=l) ((psol+s)->h)--;
              continue;
             }
          if ((psol+s)->bln==0)
             {(psol+s)->h=j;
              for (i=1;i<=(psol+r)->aln;i++) if (a(r,i)==s) {q=i;break;}
              a(r,q)=a(r,(psol+r)->aln);((psol+r)->aln)--;
              continue;
             }
          lmost=n;
          for (i=1;i<=(psol+s)->bln;i++)
             {t=(psol+b(s,i))->pi;
              if (t<k || t>=l) continue;
              if (t<lmost) {lmost=t;z=b(s,i);}
             }
          if (lmost==n) {(psol+s)->h=l;continue;}
          (psol+s)->h=lmost;
          for (i=1;i<=(psol+r)->aln;i++) if (a(r,i)==s) {q=i;break;}
          a(r,q)=a(r,(psol+r)->aln);((psol+r)->aln)--;
          ((psol+z)->aln)++;a(z,(psol+z)->aln)=s;
         }
      if ((psol+r)->h>=k)
         {if ((psol+r)->bln==0) (psol+r)->h=l;
           else
             {lmost=n;
              for (i=1;i<=(psol+r)->bln;i++)
                 {t=(psol+b(r,i))->pi;
                  if (t<lmost) {lmost=t;z=b(r,i);}
                 }
              (psol+r)->h=lmost;
              ((psol+z)->aln)++;a(z,(psol+z)->aln)=r;
             }
         }
     }
 }


 long local_search_insertions(int n,Instance *pinst,Solution *psol)
 {int i,j,k,l,z;
  int r,s,u;
  int x;
  int rbest,lbest;
  int best_change=-1;
  int delta,delta0,lend,hr;
  int leftp,leftn;
  long value_change=0;

  while (best_change<0)
     {best_change=0;
// All pairs of type (vertex, its new position in the permutation) are searched
      for (r=1;r<=n;r++) 
         {k=(psol+r)->pi;
// Preparing "y" and "z" arrays
          for (j=1;j<=(psol+r)->aln;j++) 
             {u=a(r,j);
              leftp=n;
              for (i=1;i<=(psol+u)->dln;i++) 
                 {s=d(u,i);if (s==r) continue;
                  l=(psol+s)->pi;
                  if (l<(psol+u)->pi && l<leftp) {leftp=l;leftn=s;}
                 }
              if (leftp<n) ((psol+leftn)->z)++;
               else ((psol+u)->z)++;
             }
          for (i=1;i<=(psol+r)->dln;i++) 
             {u=d(r,i);
              s=(psol+(psol+u)->h)->p;if (s==u || (psol+s)->pi>=k) continue;
              ((psol+s)->y)++;
             }
// Evaluating insertions to the left
          delta=0;lend=(psol+r)->aln;hr=(psol+r)->h;
          for (l=k-1;l>=1;l--)
             {s=(psol+l)->p;
              x=(psol+s)->y;
              delta0=lend-(psol+s)->aln+x;
              if (gr(r,s)>0)
                 {if (hr==l) delta0++;
                  if ((psol+s)->h==l) x++;
                 }
               else
                 {if (hr<l) delta0--;
                  if ((psol+s)->h<l) delta0++;
                 }
              lend+=x;
              delta+=delta0;
              if (delta>=REJECT_THRESHOLD) break;
              if (delta<best_change) {best_change=delta;rbest=r;lbest=l;}
             } // for l
// Evaluating insertions to the right
          delta=0;lend=(psol+r)->aln;
          if (hr<k) z=1; else z=0;
          for (l=k+1;l<=n;l++)
             {s=(psol+l)->p;
              lend-=((psol+s)->z);
              if (lend<=0 && z==1) break;
              delta0=(psol+s)->aln-lend;
              if (gr(r,s)>0) {if (z==0) z=1;}
               else
                 {if (z==1) delta0++;
                  if ((psol+s)->h<l) delta0--;
                 }
              delta+=delta0;
//              if (delta>=REJECT_THRESHOLD) break;
              if (delta<best_change) {best_change=delta;rbest=r;lbest=l;}
             } // for l
// Clearing "y" and "z" arrays
          for (j=1;j<=(psol+r)->aln;j++) 
             {u=a(r,j);
              leftp=n;
              for (i=1;i<=(psol+u)->dln;i++) 
                 {s=d(u,i);if (s==r) continue;
                  l=(psol+s)->pi;
                  if (l<(psol+u)->pi && l<leftp) {leftp=l;leftn=s;}
                 }
              if (leftp<n) (psol+leftn)->z=0;
               else (psol+u)->z=0;
             }
          for (i=1;i<=(psol+r)->dln;i++) 
             {u=d(r,i);
              s=(psol+(psol+u)->h)->p;if (s==u || (psol+s)->pi>=k) continue;
              (psol+s)->y=0;
             }
         } // for r
// If best_change<0, then an improving insertion is detected
      if (best_change<0)
// Performing insertion
         {perform_insertion(n,rbest,lbest,pinst,psol);
          value_change+=best_change;
         }
     }
  return value_change;
 }


 void shake(int n,int interch_req,double coef,double *seed,Solution *psol)
 {int k,l,r,s;
  int interch_count=0;
  int ind1,ind2,rem;

// Taking the best solution found thus far
  for (k=1;k<=n;k++) {(psol+k)->p=(psol+k)->bp;(psol+(psol+k)->p)->pi=k;(psol+k)->av=k;}
  rem=n;
  while (interch_count<interch_req)
// Selecting a pair of vertices
     {ind1=random(seed,coef)*rem+1;
      ind2=random(seed,coef)*(rem-1)+1;if (ind2>=ind1) ind2++;
      r=(psol+ind1)->av;s=(psol+ind2)->av;
      interch_count++;
// Exchanging positions of the selected vertices
      k=(psol+r)->pi;l=(psol+s)->pi;
      (psol+k)->p=s;(psol+l)->p=r;(psol+r)->pi=l;(psol+s)->pi=k;
// Removing the selected pair from the set of available vertices
      if (ind2<rem)
         {(psol+ind1)->av=(psol+rem)->av;rem--;
          (psol+ind2)->av=(psol+rem)->av;rem--;
         }
       else
         {rem--;(psol+ind1)->av=(psol+rem)->av;rem--;}
     }
 }


 long variable_neighborhood_search(FILE *out,int n,int ec,int dist_min,
      long time_limit,double time_limit_sa,int *time_values_opt,
      double *time_to_opt,double *sa_time,double *seed1,clock_t start_time,
      Instance *pinst,Solution *psol)
 {int j;
  int dist;
  int st=0;
  int stop_cond=0;
  int dist_max,dist_step;
  long best_value,sol_value;
  double seed2,seed3,coef;
  double fct,db;
  double elapsed_time;
  clock_t end,sa_start,sa_end;

  coef=2048;coef*=1024;coef*=1024;coef-=1;
  seed2=2*(*seed1);seed3=3*(*seed1);
  (psol+1)->perf=0;(psol+10)->perf=0;

// Initialization
  prepare_data(n,ec,pinst,psol);
  if (time_limit_sa>0.001)
// Applying Multi-start Simulated Annealing (MSA) algorithm
     {sa_start=clock();
      best_value=msa(n,ec,time_limit_sa,coef,time_values_opt,time_to_opt,
          seed1,start_time,pinst,psol);
      sa_end=clock();
      *sa_time=(sa_end-sa_start)/CLK_TCK;
      (psol+7)->perf=best_value;
      (psol+1)->perf=0;(psol+2)->perf=0;
      elapsed_time=(long)(sa_end-start_time)/CLK_TCK;
      if (elapsed_time>=time_limit) return best_value;
     }
   else random_start(n,coef,seed1,psol);

// Initial iteration of local search
  sol_value=init_insertions(n,ec,pinst,psol);
  if (time_limit_sa<=0.001)
     {best_value=sol_value;
      for (j=1;j<=n;j++) (psol+j)->bp=(psol+j)->p;
      *time_to_opt=take_time(time_values_opt,start_time);
     }
  if (sol_value!=best_value)
     {fprintf(out,
      "!!! some discrepancy in solution values:  SA_value=%12ld  calc_value=%12ld\n",best_value,sol_value);
      exit(1);
     }
  sol_value+=local_search_insertions(n,pinst,psol);
  ((psol+10)->perf)++;
  if (sol_value<best_value)
     {store_new_best_sol(n,0,time_values_opt,time_to_opt,start_time,psol);
      best_value=sol_value;
     }
  while (stop_cond==0)
     {dist=dist_min;
// Parameters used in the current iteration of variable neighborhood search
      fct=random(&seed3,coef)*(DISTANCE_MAX_HIGH-DISTANCE_MAX_LOW)+DISTANCE_MAX_LOW;
      db=fct*n;dist_max=db;if (dist_max>n/2) dist_max=n/2;
      dist_step=db/DISTANCE_STEP_COEF;if (dist_step<1) dist_step=1;
      st++;
      while (dist<=dist_max && stop_cond==0)
// Shaking
         {shake(n,dist,coef,&seed2,psol);
// Local search
          sol_value=init_insertions(n,ec,pinst,psol);
          sol_value+=local_search_insertions(n,pinst,psol);
          ((psol+10)->perf)++;
// Applying neighborhood change rule
          if (sol_value<best_value)
             {store_new_best_sol(n,st,time_values_opt,time_to_opt,start_time,psol);
              best_value=sol_value;
              dist=dist_min;
             }
           else dist+=dist_step;
// Checking variable neighborhood search termination rule
          end=clock();
          elapsed_time=(end-start_time)/CLK_TCK;
          if (elapsed_time>=time_limit) stop_cond=1;
         } // inner while
     } // outer while
// Storing the total number of variable neighborhood search starts executed
  (psol+3)->perf=st;
  return best_value;
 }




// "pmp_sa_vns" is a simulated annealing and variable neighborhood search hybrid for the profile minimization problem
 void pmp_sa_vns(char *in_file_name,char *out_file_name,double seed,
      long time_limit,Results *pres)
 {FILE *out,*in;
  Instance *pinst;
  Solution *psol;

  int i,j;
  int n,ec;
  int v1,v2;
  int dist_min;
  int time_values[5],time_values_opt[5];
  long best_value,sol_value;
  double time_limit_sa;
  double time_in_seconds,time_to_opt,sa_time;
  double seed_saved;
  double doub;
  clock_t start_time;

  if ((in=fopen(in_file_name,"r"))==NULL)
     {printf("  fopen failed for input");exit(1);}
// n is the number of vertices and ec is the number of edges
  fscanf(in,"%d %d",&n,&ec);
  if ((out=fopen(out_file_name,"w"))==NULL)
     {printf("  fopen failed for output  %s",out_file_name);exit(1);}
  seed_saved=seed;
// Allocation of core memory for an array of Instance structure objects 
  ALS(pinst,Instance,n+1)
  for (i=0;i<=n;i++) ALI((pinst+i)->gr,n+1)
  for (i=0;i<=1;i++) ALI((pinst+i)->edge,ec+1)
// Allocation of core memory for an array of Solution structure objects 
// that contains data used in various methods. 
// ST_COUNT is the length of performance statistics array 'perf'
  if (n>ST_COUNT) i=n; else i=ST_COUNT;
  ALS(psol,Solution,i+1)

// Input of the graph
  for (i=1;i<=n;i++) (psol+i)->deg=0;
  for (i=1,j=0;i<=ec;i++)
// One of below given input statements must be used (uncommented)
     {fscanf(in,"%d %d",&v1,&v2);
      //fscanf(in,"%d %d %lf",&v1,&v2,&doub);
      if (v1==v2) continue; // vertex loops are ignored
      gr(v1,v2)=gr(v2,v1)=1;
      j++;
      edge(0,j)=v1;edge(1,j)=v2;
      ((psol+v1)->deg)++;((psol+v2)->deg)++;
     }
  ec=j;

  ALI(pinst->a,n)
  ALI((pinst+1)->a,n)
  ALI(pinst->d,n)
  ALI(pinst->b,n)
  for (i=2;i<=n;i++) ALI((pinst+i)->a,(psol+i)->deg+1)
  for (i=1;i<=n;i++) ALI((pinst+i)->b,(psol+i)->deg+1)
  for (i=1;i<=n;i++) ALI((pinst+i)->d,(psol+i)->deg+1)

  dist_min=DISTANCE_MIN;
  doub=SA_TIME_QUOTA;
  if (doub>=1) time_limit_sa=time_limit; else time_limit_sa=time_limit*doub;
  start_time=clock();
// Running variable neighborhood search with multi-start simulated annealing incorporated
  best_value=variable_neighborhood_search(out,n,ec,dist_min,time_limit,time_limit_sa,
      time_values_opt,&time_to_opt,&sa_time,&seed,start_time,pinst,psol);
  time_in_seconds=take_time(time_values,start_time);
  (psol+6)->perf=best_value;
  sol_value=get_best_value(n,ec,pinst,psol);
  if (best_value != sol_value) fprintf(out,
      "!!! some discrepancy in solution values: %8ld   %8ld\n",best_value,sol_value);

// Printing parameters, data characteristics and some statistics 
// regarding the performance of the algorithm
  fprintf(out,"   parameters:                                 \n");
  fprintf(out,"      SA_TIME_QUOTA                          = %5lf\n",SA_TIME_QUOTA);
  fprintf(out,"      DISTANCE_MIN                           = %5d\n",DISTANCE_MIN);
  fprintf(out,"      DISTANCE_MAX_LOW                       = %6lf\n",DISTANCE_MAX_LOW);
  fprintf(out,"      DISTANCE_MAX_HIGH                      = %6lf\n",DISTANCE_MAX_HIGH);
  fprintf(out,"      DISTANCE_STEP_COEF                     = %5d\n",DISTANCE_STEP_COEF);
  fprintf(out,"      REJECT_THRESHOLD                       = %3d\n",REJECT_THRESHOLD);
  fprintf(out,"      COOLING_FACTOR                         = %6lf\n",COOLING_FACTOR);
  fprintf(out,"      MIN_TEMPERATURE                        = %8lf\n",MIN_TEMPERATURE);
  fprintf(out,"      TEMPERATURE_COEF1                      = %3d\n",TEMPERATURE_COEF1);
  fprintf(out,"      TEMPERATURE_COEF2                      = %3d\n",TEMPERATURE_COEF2);
  fprintf(out,"      SIZE_THRESHOLD                         = %5d\n",SIZE_THRESHOLD);
  fprintf(out,"      SAMPLE_SIZE                            = %5d\n",SAMPLE_SIZE);
  fprintf(out,"      seed for random number generator       = %8lf\n",seed_saved);
  fprintf(out,"   number of vertices                        = %5d\n",n);
  fprintf(out,"   number of edges                           = %5d\n",ec);
  fprintf(out,"   time limit                                = %5ld\n",time_limit);
  if ((psol+7)->perf>0)
     {fprintf(out,"   number of SA restarts executed            = %4ld\n",(psol+13)->perf);
      fprintf(out,"   number of improvements during SA          = %4ld\n",(psol+14)->perf);
      fprintf(out,"   last improvement at SA restart no.        = %3ld\n",(psol+15)->perf);
      fprintf(out,"   value found by SA                         = %8ld\n",(psol+7)->perf);
      fprintf(out,"   time taken by SA                          = %12lf\n",sa_time);
     }
   if ((psol+10)->perf>0)
     {fprintf(out,"   number of VNS starts executed             = %4ld\n",(psol+3)->perf);
      fprintf(out,"   number of improvements during VNS         = %4ld\n",(psol+1)->perf);
      fprintf(out,"   last improvement at VNS start no.         = %3ld\n",(psol+2)->perf);
      fprintf(out,"   total of LS starts                        = %4ld\n",(psol+10)->perf);
      fprintf(out,"   value found by VNS                        = %8ld\n",(psol+6)->perf);
     }
  (psol+4)->perf=(long)time_to_opt;
  fprintf(out,"   time to the best solution: %d : %d : %d.%3d  (=%4ld seconds)\n",
      time_values_opt[1],time_values_opt[2],time_values_opt[3],time_values_opt[4],(long)time_to_opt);
  (psol+5)->perf=(long)time_in_seconds;
  fprintf(out,"   total time of the algorithm: %d : %d : %d.%3d  (=%4ld seconds)\n",
      time_values[1],time_values[2],time_values[3],time_values[4],(long)time_in_seconds);
  fflush(out);

// Saving results
  if (pres!=NULL)
     {pres->value=best_value;
      pres->total_time=time_in_seconds;
      pres->time_to_best=time_to_opt;
      pres->characts[0]=n;
      if (pres->sol==NULL) ALI(pres->sol,n+1)
      for (i=1;i<=n;i++) sol(i)=(psol+i)->bp;
     }

// Releasing the memory
  if (psol!=NULL) free(psol);
  for (i=0;i<=n;i++) if ((pinst+i)->d!=NULL) free((pinst+i)->d);
  for (i=0;i<=n;i++) if ((pinst+i)->b!=NULL) free((pinst+i)->b);
  for (i=0;i<=n;i++) if ((pinst+i)->a!=NULL) free((pinst+i)->a);
  for (i=0;i<=1;i++) if ((pinst+i)->edge!=NULL) free((pinst+i)->edge);
  for (i=0;i<=n;i++) if ((pinst+i)->gr!=NULL) free((pinst+i)->gr);
  if (pinst!=NULL) free(pinst);
// Closing input and output files
  fclose(out);fclose(in);
 }
