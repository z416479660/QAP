#include <stdio.h>

// Simulated annealing
#define COOLING_FACTOR           0.95
#define MIN_TEMPERATURE        0.0001
#define TEMPERATURE_COEF          100
#define SAMPLE_SIZE              5000
#define PROB_LS                     0
#define MOVE_COEF                 0.5

#define ST_COUNT                   15

#define ALS(X,Y,Z) if ((X=(Y *)calloc(Z,sizeof(Y)))==NULL) \
       {fprintf(out,"  failure in memory allocation\n");exit(0);}
#define ALI(X,Z) if ((X=(int *)calloc(Z,sizeof(int)))==NULL) \
       {fprintf(out,"  failure in memory allocation\n");exit(0);}

#define w(X,Y) *((pin+X)->w+Y)
#define wd(X,Y) *((pin+X)->wd+Y)
#define d(X,Y) *((pin+X)->d+Y)
#define a(X,Y) *((pin+X)->a+Y)
#define b(X,Y) *((pin+X)->b+Y)
#define lsum(X,Y) *((pin+X)->lsum+Y)
#define ldif(X,Y) *((pin+X)->ldif+Y)
#define sol(X,Y) *((pres+X)->sol+Y)


typedef struct
     {int *w;         /*  */
      int *wd;        /*  */
      int *d;         /*  */
      int *a;         /*  */
      int *b;         /*  */
      int *lsum;      /*  */
      int *ldif;      /*  */
     }Instance;

typedef struct
     {int len;      /*  */
      int l;        /*  */
      int p;        /*  */
      int bp;       /*  */
      int rp;       /*  */
      int brp;      /*  */
      int c;        /*  */
      int csum;     /*  */
      int cdif;     /*  */
      int cp;       /*  */
      int a;        /*  */
      int e;        /*  */
      long perf;    /*  */
     }Solution;

typedef struct
     {int *sol;             /* solution obtained                     */
      double value;         /* solution value                        */
      double time_to_best;  /* time to the SA best solution, secs    */
      double total_time;    /* total time, secs                      */
      int characts[10];     /* some characteristics:                 */
                            /*    characts[0] - number of facilities */
     }Results;