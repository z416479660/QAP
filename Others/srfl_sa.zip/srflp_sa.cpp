/* Program: an implementation of the simulated annealing (SA) 
     algorithm for the single row facility layout problem (SRFLP): 
         Arrange facilities with given lengths on a line such that 
         the weighted sum of the distances between all pairs of facilities 
         is as small as possible.
   Author: Gintaras Palubeckis
   Date: 2015-11-16
   Language: C++
   Some of the input data are supplied through the parameters and the rest 
   through the (input) file. An instance of the SRFLP in this file is 
   represented by the array of lenghts of facilities and the flow  
   matrix. The program terminates either when a specified time limit is reached 
   or after completing the first run of the SA procedure when the allotted 
   time interval is insufficient to do this. In the former case, SA procedure 
   is restarted with a new randomly generated permutation.
   Parameters:
     - input file name;
     - output file name;
     - seed for random number generator;
     - time limit (in seconds);
     - a pointer to structure 'Results' for writing down the solution found 
       and the performance characteristics. The structure is defined in 
       file 'srflp_sa.h'. It is possible to have the last parameter null: 
       in this case, information is directed only to the output file.
   Examples of invocation:
       either
     Results *pres;
     char in_file_name[80],out_file_name[80];
     double seed=1000;
     pres=(Results *)calloc(1,sizeof(Results));
     strcpy(in_file_name,"D:\\data\\AnKeVa_2005_80dept_set3");
     strcpy(out_file_name,"D:\\temp\\AnKeVa_2005_80dept_set3.res");
     srflp_sa(in_file_name,out_file_name,seed,10,pres);
       or just
     char in_file_name[80],out_file_name[80];
     double seed=1000;
     strcpy(in_file_name,"D:\\data\\AnKeVa_2005_80dept_set3");
     strcpy(out_file_name,"D:\\temp\\AnKeVa_2005_80dept_set3.res");
     srflp_sa(in_file_name,out_file_name,seed,10,NULL);
   Input file contains:
     - the number of facilities;
     - their lenghts;
     - the (symmetric) flow matrix W. 
   Example of the input file:
   80 
   17 13 27 63 39 26 13 17 66 54 21 44 42 16 22 71 24 10 19 63 ...
   0 2 3 4 3 3 7 3 10 3 4 5 2 5 6 2 4 3 6 2 0 1 5 2 2 2 2 3 0 ...
   2 0 2 2 3 1 3 1 7 4 2 2 1 4 2 1 4 2 3 2 1 2 3 0 1 1 1 2 0 3 ...
   3 2 0 2 1 1 5 1 2 2 3 3 1 3 2 1 3 0 4 0 1 2 2 2 2 2 2 1 0 1 ...
   .............
   .............
   .............
*/



#include <alloc.h>
#include <process.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "srflp_sa.h"



 double random(double *seed,double coef)
 {double rd,rf;
  rd=16807*(*seed);rf=floor(rd/coef);
  *seed=rd-rf*coef;
  return(*seed/(coef+1));
 }


 double take_time(int *time_values,clock_t start)
 {int i;
  int hours,mins;
  long longsecs;
  double elapsed_sec;
  clock_t end;
  end=clock();
  elapsed_sec=(end-start)/CLK_TCK;
  longsecs=elapsed_sec;
  for (i=1;i<=4;i++) time_values[i]=0;
  hours=(int)(longsecs/3600);
  if (hours>0)     /* more than an hour  */
     {time_values[1]=hours;longsecs-=hours*3600;}
  mins=(int)(longsecs/60);
  if (mins>0)     /* more than a minute */
     {time_values[2]=mins;longsecs-=mins*60;}
  time_values[3]=(int)longsecs;
  time_values[4]=elapsed_sec*1000-(long)elapsed_sec*1000;
  return elapsed_sec;
 }


 double get_best_value(int n,Instance *pin,Solution *psol)
 {int i,j;
  int u,v;
  int dist=0,incr;
  double calc_sol_value=0;

  for (i=1;i<=n;i++)
     {u=(psol+i)->bp;
      (psol+i)->cp=dist+(psol+u)->l;dist+=((psol+u)->len);
     }
  for (i=1;i<n;i++)
     {u=(psol+i)->bp;
      for (j=i+1;j<=n;j++)
         {v=(psol+j)->bp;
          dist=(psol+j)->cp-(psol+i)->cp;incr=w(u,v)*dist;
          calc_sol_value+=incr;
         }
     }
  return calc_sol_value;
 }


 double random_start(int n,double coef,double *seed,Instance *pin,
      Solution *psol)
 {int i,j,k;
  int u,v;
  int dist=0,incr;
  double sol_value=0;

// Randomly generating permutation
  for (i=1;i<=n;i++) (psol+i)->a=i;
  for (i=1;i<=n;i++)
     {k=random(seed,coef)*(n-i+1);k+=i;
      (psol+i)->p=(psol+k)->a;(psol+(psol+k)->a)->rp=i;
      (psol+k)->a=(psol+i)->a;
     }
  psol->p=0;(psol+n+1)->p=0;
// Calculating distance matrix D as well as solution value
  for (i=1;i<=n;i++)
     {u=(psol+i)->p;
      (psol+i)->cp=dist+(psol+u)->l;dist+=((psol+u)->len);
     }
  for (i=1;i<n;i++)
     {u=(psol+i)->p;
      for (j=i+1;j<=n;j++)
         {v=(psol+j)->p;
          d(u,v)=(psol+j)->cp-(psol+i)->cp;d(v,u)=d(u,v);incr=w(u,v)*d(u,v);
          sol_value+=((double)incr);
         }
     }
  return sol_value;
 }


 void init_data1(int n,Instance *pin,Solution *psol)
 {int j;
  int m;
  int u,v;

// Initializing auxiliary array E(.)
  for (u=1;u<=n;u++) (psol+u)->e=0;
  for (m=1;m<n;m++)
     {u=(psol+m)->p;
      for (j=m+1;j<=n;j++) {v=(psol+j)->p;(psol+u)->e+=(w(u,v));(psol+v)->e-=(w(u,v));}
     }
// Initializing cuts vector
  psol->c=0;(psol+n)->c=(psol+n+1)->c=0;
  for (m=1;m<n;m++) (psol+m)->c=(psol+m-1)->c+(psol+(psol+m)->p)->e;
 }


 void init_data2(int n,Instance *pin,Solution *psol)
 {int i,j;
  int m;
  int u,v;
  int dist=0;

// Initializing auxiliary matrix A
  for (u=1;u<=n;u++)
     {m=(psol+u)->rp;a(u,m)=0;
      for (i=m-1;i>=1;i--) a(u,i)=a(u,i+1)+w(u,(psol+i)->p);
      for (i=m+1;i<=n;i++) a(u,i)=a(u,i-1)+w(u,(psol+i)->p);
     }
// Initializing auxiliary matrix B
  for (u=1;u<=n;u++)
     {m=(psol+u)->rp;b(u,m)=0;
      for (i=m-1;i>=1;i--)
         {v=(psol+i)->p;
          b(u,i)=b(u,i+1)+a(u,i+1)*ldif(v,u)+a(u,i)*lsum(v,u);
         }
      for (i=m+1;i<=n;i++)
         {v=(psol+i)->p;
          b(u,i)=b(u,i-1)+a(u,i-1)*ldif(v,u)+a(u,i)*lsum(v,u);
         }
     }
// Calculating distance matrix D
  for (i=1;i<=n;i++)
     {u=(psol+i)->p;
      (psol+i)->cp=dist+(psol+u)->l;dist+=((psol+u)->len);
     }
  for (i=1;i<n;i++)
     {u=(psol+i)->p;
      for (j=i+1;j<=n;j++)
         {v=(psol+j)->p;
          d(u,v)=(psol+j)->cp-(psol+i)->cp;d(v,u)=d(u,v);
         }
     }
// Initializing cuts vector and its derivatives "csum" and "cdif"
  psol->c=0;(psol+n)->c=(psol+n+1)->c=0;
  for (m=1;m<n;m++)
     {u=(psol+m)->p;
      (psol+m)->c=(psol+m-1)->c+a(u,n)-a(u,1);
      (psol+m)->csum=(psol+m)->c+(psol+m-1)->c;
      (psol+m)->cdif=(psol+m)->c-(psol+m-1)->c;
     }
  (psol+n)->csum=(psol+n-1)->c;(psol+n)->cdif=-(psol+n-1)->c;
 }


 void update_sol_interchange1(int k,int l,Instance *pin,Solution *psol)
 {int m;
  int r,s,u;

// Performing interchange
  r=(psol+k)->p;s=(psol+l)->p;
  (psol+k)->p=s;(psol+l)->p=r;
  (psol+r)->rp=l;(psol+s)->rp=k;
// Updating E(.) entries
  for (m=k+1;m<l;m++)
     {u=(psol+m)->p;
      (psol+u)->e+=(wd(u,r)-wd(u,s));
      (psol+r)->e-=(wd(u,r));(psol+s)->e+=(wd(u,s));
     }
  (psol+r)->e-=(wd(r,s));(psol+s)->e+=(wd(r,s));
// Updating cuts vector
  for (m=k;m<l;m++) (psol+m)->c=(psol+m-1)->c+(psol+(psol+m)->p)->e;
 }


 void update_sol_interchange2(int n,int k,int l,Instance *pin,Solution *psol)
 {int i,i1,i2;
  int m;
  int r,s,u,v,z;

// Performing interchange
  r=(psol+k)->p;s=(psol+l)->p;
  (psol+k)->p=s;(psol+l)->p=r;
  (psol+r)->rp=l;(psol+s)->rp=k;
// Updating matrices A, B and D
  for (u=1;u<=n;u++)
     {m=(psol+u)->rp;
      if (m<k)
         {for (i=k;i<l;i++)
             {v=(psol+i-1)->p;z=(psol+i)->p;
              a(u,i)=a(u,i-1)+w(u,z);
              d(u,z)=d(u,v)+lsum(v,z);d(z,u)=d(u,z);
              b(u,i)=b(u,i-1)+a(u,i-1)*ldif(z,u)+a(u,i)*lsum(z,u);
             }
          for (i=l;i<=n;i++)
             {v=(psol+i-1)->p;z=(psol+i)->p;
              d(u,z)=d(u,v)+lsum(v,z);d(z,u)=d(u,z);
//              if (i==n) continue;
              b(u,i)=b(u,i-1)+a(u,i-1)*ldif(z,u)+a(u,i)*lsum(z,u);
             }
         }
       else if (m>l)
         {for (i=l;i>k;i--)
             {v=(psol+i)->p;
              a(u,i)=a(u,i+1)+w(u,v);
              b(u,i)=b(u,i+1)+a(u,i+1)*ldif(v,u)+a(u,i)*lsum(v,u);
             }
//          for (i=k;i>=2;i--)
          for (i=k;i>=1;i--)
             {v=(psol+i)->p;
              b(u,i)=b(u,i+1)+a(u,i+1)*ldif(v,u)+a(u,i)*lsum(v,u);
             }
         }
        else
         {if (k<m && m<l) {i1=k;i2=l;} else {i1=m-1;i2=m+1;a(u,m)=0;b(u,m)=0;}
          for (i=i1;i>=1;i--)
             {v=(psol+i)->p;
              a(u,i)=a(u,i+1)+w(u,v);
//              if (i==1) continue;
              b(u,i)=b(u,i+1)+a(u,i+1)*ldif(v,u)+a(u,i)*lsum(v,u);
             }
          for (i=i2;i<=n;i++)
             {v=(psol+i-1)->p;z=(psol+i)->p;
              a(u,i)=a(u,i-1)+w(u,z);
              d(u,z)=d(u,v)+lsum(v,z);d(z,u)=d(u,z);
//              if (i==n) continue;
              b(u,i)=b(u,i-1)+a(u,i-1)*ldif(z,u)+a(u,i)*lsum(z,u);
             }
         }
     }
// Updating cuts vector
  for (i=k;i<l;i++)
     {u=(psol+i)->p;
      (psol+i)->c=(psol+i-1)->c+a(u,n)-a(u,1);
      (psol+i)->csum=(psol+i)->c+(psol+i-1)->c;
      (psol+i)->cdif=(psol+i)->c-(psol+i-1)->c;
     }
  (psol+l)->csum=(psol+l)->c+(psol+l-1)->c;(psol+l)->cdif=(psol+l)->c-(psol+l-1)->c;
 }


 void update_sol_insertion1(int k,int l,Instance *pin,Solution *psol)
 {int m;
  int r,s;
  int alpha,beta;

// Performing insertion and updating E(.) entries
  r=(psol+k)->p;
  if (k<l)
     {for (m=k;m<l;m++)
         {s=(psol+m+1)->p;
          (psol+m)->p=s;(psol+s)->rp=m;
          (psol+s)->e+=(wd(s,r));(psol+r)->e-=(wd(s,r));
         }
      alpha=k;beta=l;
     }
   else
     {for (m=k;m>l;m--)
         {s=(psol+m-1)->p;
          (psol+m)->p=s;(psol+s)->rp=m;
          (psol+s)->e-=(wd(s,r));(psol+r)->e+=(wd(s,r));
         }
      alpha=l;beta=k;
     }
  (psol+l)->p=r;(psol+r)->rp=l;
// Updating cuts vector
  for (m=alpha;m<beta;m++) (psol+m)->c=(psol+m-1)->c+(psol+(psol+m)->p)->e;
 }


 void update_sol_insertion2(int n,int k,int l,Instance *pin,Solution *psol)
 {int i,i1,i2;
  int m;
  int r,s,u,v,z;
  int alpha,beta;

// Performing insertion
  r=(psol+k)->p;
  if (k<l)
     {for (i=k;i<l;i++)
         {s=(psol+i+1)->p;
          (psol+i)->p=s;(psol+s)->rp=i;
         }
      alpha=k;beta=l;
     }
   else
     {for (i=k;i>l;i--)
         {s=(psol+i-1)->p;
          (psol+i)->p=s;(psol+s)->rp=i;
         }
      alpha=l;beta=k;
     }
  (psol+l)->p=r;(psol+r)->rp=l;
// Updating matrices A, B and D
  for (u=1;u<=n;u++)
     {m=(psol+u)->rp;
      if (m<alpha)
         {for (i=alpha;i<beta;i++)
             {v=(psol+i-1)->p;z=(psol+i)->p;
              a(u,i)=a(u,i-1)+w(u,z);
              d(u,z)=d(u,v)+lsum(v,z);d(z,u)=d(u,z);
              b(u,i)=b(u,i-1)+a(u,i-1)*ldif(z,u)+a(u,i)*lsum(z,u);
             }
          for (i=beta;i<=n;i++)
             {v=(psol+i-1)->p;z=(psol+i)->p;
              d(u,z)=d(u,v)+lsum(v,z);d(z,u)=d(u,z);
              b(u,i)=b(u,i-1)+a(u,i-1)*ldif(z,u)+a(u,i)*lsum(z,u);
             }
         }
       else if (m>beta)
         {for (i=beta;i>alpha;i--)
             {v=(psol+i)->p;
              a(u,i)=a(u,i+1)+w(u,v);
              b(u,i)=b(u,i+1)+a(u,i+1)*ldif(v,u)+a(u,i)*lsum(v,u);
             }
          for (i=alpha;i>=1;i--)
             {v=(psol+i)->p;
              b(u,i)=b(u,i+1)+a(u,i+1)*ldif(v,u)+a(u,i)*lsum(v,u);
             }
         }
       else if (m==l)
         {a(u,m)=0;b(u,m)=0;
          for (i=l-1;i>=1;i--)
             {v=(psol+i)->p;
              a(u,i)=a(u,i+1)+w(u,v);
              b(u,i)=b(u,i+1)+a(u,i+1)*ldif(v,u)+a(u,i)*lsum(v,u);
             }
          for (i=l+1;i<=n;i++)
             {v=(psol+i-1)->p;z=(psol+i)->p;
              a(u,i)=a(u,i-1)+w(u,z);
              d(u,z)=d(u,v)+lsum(v,z);d(z,u)=d(u,z);
              b(u,i)=b(u,i-1)+a(u,i-1)*ldif(z,u)+a(u,i)*lsum(z,u);
             }
         }
       else
         {if (k<l)
             {for (i=k;i<l;i++) {a(u,i)=a(u,i+1);b(u,i)=b(u,i+1);}
              i1=k-1;i2=l;
             }
           else // if (l<k)
             {for (i=k;i>l;i--) {a(u,i)=a(u,i-1);b(u,i)=b(u,i-1);}
              i1=l;i2=k+1;
             }
          for (i=i1;i>=1;i--)
             {v=(psol+i)->p;
              a(u,i)=a(u,i+1)+w(u,v);
              b(u,i)=b(u,i+1)+a(u,i+1)*ldif(v,u)+a(u,i)*lsum(v,u);
             }
          for (i=i2;i<=n;i++)
             {v=(psol+i-1)->p;z=(psol+i)->p;
              a(u,i)=a(u,i-1)+w(u,z);
              d(u,z)=d(u,v)+lsum(v,z);d(z,u)=d(u,z);
              b(u,i)=b(u,i-1)+a(u,i-1)*ldif(z,u)+a(u,i)*lsum(z,u);
             }
         }
     }
// Updating cuts vector
  for (i=alpha;i<beta;i++)
     {u=(psol+i)->p;
      (psol+i)->c=(psol+i-1)->c+a(u,n)-a(u,1);
      (psol+i)->csum=(psol+i)->c+(psol+i-1)->c;
      (psol+i)->cdif=(psol+i)->c-(psol+i-1)->c;
     }
  (psol+beta)->csum=(psol+beta)->c+(psol+beta-1)->c;
  (psol+beta)->cdif=(psol+beta)->c-(psol+beta-1)->c;
 }


 long init_temperature(int n,int sam_size,double coef,double *seed,Instance *pin,
      Solution *psol)
 {int i,j,k,l;
  int r,s;
  long t_max=-1,dif;

  for (j=1;j<=sam_size;j++)
     {r=random(seed,coef)*n;if (r<n) r++;k=(psol+r)->rp;
      s=r;
      while (s==r) {s=random(seed,coef)*n;if (s<n) s++;}
      l=(psol+s)->rp;
      if (l<k) {i=k;k=l;l=i;i=r;r=s;s=i;}
      if (l>k+1)
          dif=((psol+l)->cdif-(psol+k)->cdif+wd(r,s))*d(r,s)+2*(b(r,l-1)+b(s,k+1))+
              ldif(r,s)*((psol+l)->csum-(psol+k)->csum);
       else
          dif=((psol+l)->cdif-(psol+k)->cdif+wd(r,s))*d(r,s)+ldif(r,s)*((psol+l)->c-(psol+k-1)->c);
      if (dif<0) dif=-dif;
      if (dif>t_max) t_max=dif;
     }
  return t_max;
 }


 void store_new_best_sol(int n,int st,int *time_values_opt,
      double *time_to_opt,clock_t start_time,Solution *psol)
 {int r;
  for (r=1;r<=n;r++) {(psol+r)->bp=(psol+r)->p;(psol+r)->brp=(psol+r)->rp;}
  ((psol+1)->perf)++;(psol+2)->perf=st;
  *time_to_opt=take_time(time_values_opt,start_time);
 }


 double SA_implementation(int n,int interch_prob,int tred,
      int tlength,double best_value,long st,long time_limit,
      double t_max,double coef,int *stop_cond,int *time_values_opt,
      double *time_to_opt,double *seed1,double *seed2,
      clock_t start_time,Instance *pin,Solution *psol)
 {int i,k,l,m,r,s;
  int u,v;
  int tr,tl;
  int move_thr,move_change;
  int move,accept;
  long dif,cut;
  long elapsed_time;
  double sol_value;
  double t;
  double c_factor;
  double db,md;
  clock_t end_time;

  if (st==1) sol_value=best_value;
   else sol_value=random_start(n,coef,seed1,pin,psol);
  c_factor=COOLING_FACTOR;
  t=t_max;
  move_thr=MOVE_COEF*tred;move_change=move_thr+1;

  for (tr=1;tr<=tred;tr++)
     {for (tl=1;tl<=tlength;tl++)
         {if (random(seed2,coef)*100<=interch_prob) move=1; else move=2;
          if (move==1)
// Examining interchange move
             {r=random(seed2,coef)*n;if (r<n) r++;
              s=r;
              while (s==r) {s=random(seed2,coef)*n;if (s<n) s++;}
              k=(psol+r)->rp;l=(psol+s)->rp;
              if (l<k) {i=k;k=l;l=i;i=r;r=s;s=i;}
              if (tr<=move_thr)
// Computing move gain directly
                 {if (tr==1 && tl==1) init_data1(n,pin,psol);
                  cut=(psol+k-1)->c;
                  dif=(cut-(psol+l)->c)*((psol+s)->l-(psol+r)->l);
                  cut+=((psol+s)->e+wd(r,s));
                  if (l==k+1) dif+=((cut-(psol+k)->c)*lsum(r,s));
                   else
                     {for (m=k+1;m<l;m++) cut+=(wd((psol+m)->p,s));
                      u=(psol+k+1)->p;dif+=(cut*lsum(s,u)-(psol+k)->c*lsum(r,u));
                      for (m=k+1;m<=l-2;m++)
                         {cut+=((psol+u)->e+wd(u,r)-wd(u,s));v=(psol+m+1)->p;
                          dif+=((cut-(psol+m)->c)*lsum(u,v));
                          u=v;
                         }
                      cut+=((psol+u)->e+wd(u,r)-wd(u,s));
                      dif+=(cut*lsum(u,r)-(psol+l-1)->c*lsum(u,s));
                     }
                 }
               else
// Computing move gain by special formula
                 {if (tr==move_change && tl==1) init_data2(n,pin,psol);
                  if (l>k+1)
                     {dif=((psol+l)->cdif-(psol+k)->cdif+wd(r,s))*d(r,s)+2*(b(r,l-1)+b(s,k+1))+
                          ldif(r,s)*((psol+l)->csum-(psol+k)->csum);
                     }
                   else
                     {dif=((psol+l)->cdif-(psol+k)->cdif+wd(r,s))*d(r,s)+ldif(r,s)*((psol+l)->c-(psol+k-1)->c);
                    }
                 }
             }
           else
// Examining insertion move
             {r=random(seed2,coef)*n;if (r<n) r++;k=(psol+r)->rp;
              l=k;
              while (l==k) {l=random(seed2,coef)*n;if (l<n) l++;}
              if (tr<=move_thr)
                 {if (tr==1 && tl==1) init_data1(n,pin,psol);
                  if (k<l)
// Computing move gain directly (the case of insertion to the right)
                     {cut=(psol+k-1)->c;u=(psol+k+1)->p;
                      dif=cut*((psol+u)->l-(psol+r)->l);
                      if (l==k+1) {cut+=((psol+u)->e+wd(u,r));dif+=((cut-(psol+k)->c)*lsum(r,u));}
                       else
                         {dif-=((psol+k)->c*lsum(r,u));
                          for (m=k+1;m<=l-1;m++)
                             {cut+=((psol+u)->e+wd(u,r));v=(psol+m+1)->p;
                              dif+=((cut-(psol+m)->c)*lsum(u,v));
                              u=v;
                             }
                          cut+=((psol+u)->e+wd(u,r));
                          dif+=(cut*lsum(u,r));
                         }
                      dif+=((psol+l)->c*((psol+r)->l-(psol+u)->l));
                     }
                   else
// Computing move gain directly (the case of insertion to the left)
                     {cut=(psol+k)->c;u=(psol+k-1)->p;
                      dif=cut*((psol+u)->l-(psol+r)->l);
                      if (l==k-1) {cut+=(wd(u,r)-(psol+u)->e);dif+=((cut-(psol+l)->c)*lsum(r,u));}
                       else
                         {dif-=((psol+k-1)->c*lsum(r,u));
                          for (m=k-1;m>=l+1;m--)
                             {cut+=(wd(u,r)-(psol+u)->e);v=(psol+m-1)->p;
                              dif+=((cut-(psol+m-1)->c)*lsum(u,v));
                              u=v;
                             }
                          cut+=(wd(u,r)-(psol+u)->e);
                          dif+=(cut*lsum(u,r));
                         } 
                      dif+=((psol+l-1)->c*((psol+r)->l-(psol+u)->l));
                     }
                 }
               else
                 {if (tr==move_change && tl==1) init_data2(n,pin,psol);
// Computing move gain by special formulas
                  u=(psol+l)->p;
                  if (k<l)
                     {v=(psol+k+1)->p;
                      dif=2*b(r,l)-(psol+k)->cdif*(d(v,u)+lsum(v,u))+(psol+r)->len*((psol+l)->c-(psol+k)->c);
                     }
                   else
                     {v=(psol+k-1)->p;
                      dif=2*b(r,l)+(psol+k)->cdif*(d(u,v)+lsum(u,v))+(psol+r)->len*((psol+l-1)->c-(psol+k-1)->c);
                     }
                 }
             }
// Accepting or rejecting the move
          if (dif<=0) accept=2;
           else
             {md=random(seed2,coef);
              db=-dif/t;db=exp(db);
              if (md<=db) accept=1; else accept=0;
             }
          if (accept==0) continue;
// If move is accepted, then the used data are updated
          sol_value+=dif;
          if (move==1)
            {if (tr<=move_thr) update_sol_interchange1(k,l,pin,psol);
               else update_sol_interchange2(n,k,l,pin,psol);
             }
           else
            {
             if (tr<=move_thr) update_sol_insertion1(k,l,pin,psol);
               else update_sol_insertion2(n,k,l,pin,psol);
             }
          if (accept<2) continue;
          if (sol_value<best_value)
             {best_value=sol_value;
              store_new_best_sol(n,st,time_values_opt,time_to_opt,start_time,psol);
             }
         }
      end_time=clock();
      elapsed_time=(long)(end_time-start_time)/CLK_TCK;
      if (elapsed_time>=time_limit) {*stop_cond=1; break;}
      t=c_factor*t;
     }
  return best_value;
 }


 double SA(int n,int interch_prob,long time_limit,
      int *time_values_opt,double *time_to_opt,double *seed1,
      clock_t start_time,Instance *pin,Solution *psol)
 {int stop_cond=0;
  int tred;
  int tlength;
  long st=0;
  double best_value;
  double t_max,t_min;
  double c_factor;
  double coef,seed2;

  coef=2048;coef*=1024;coef*=1024;coef-=1;
  seed2=2*(*seed1);
  (psol+1)->perf=-1;

// Random linear arrangement (permutation of facilities) is generated
  best_value=random_start(n,coef,seed1,pin,psol);
  store_new_best_sol(n,st,time_values_opt,time_to_opt,start_time,psol);
  init_data2(n,pin,psol);
// Setting parameter values
  t_max=init_temperature(n,SAMPLE_SIZE,coef,seed1,pin,psol);
  t_min=MIN_TEMPERATURE;c_factor=COOLING_FACTOR;
  tred=(log(t_min)-log(t_max))/log(c_factor);(psol+7)->perf=tred;
  tlength=TEMPERATURE_COEF*n;(psol+8)->perf=tlength;
// Multi-start simulated annealing ...
  while (stop_cond==0)
     {st++;
      best_value=SA_implementation(n,interch_prob,tred,tlength,
          best_value,st,time_limit,t_max,coef,&stop_cond,time_values_opt,
          time_to_opt,seed1,&seed2,start_time,pin,psol);
//if (st==1) break;
     }
// Storing the total number of simulated annealing restarts executed
  (psol+3)->perf=st;
  return best_value;
 }




// 'srflp_sa' is a linear arrangement procedure
 void srflp_sa(char *in_file_name,char *out_file_name,double seed,
      long time_limit,Results *pres)
 {FILE *out,*in;
  Instance *pin;
  Solution *psol;

  int i,j;
  int n;
  int val;
  int time_values[5],time_values_opt[5];
  double best_value,best_value_doubled,sol_value_doubled;
  double time_in_seconds,time_to_opt;
  double seed_saved;
  double epsilon=0.000001;
  clock_t start_time;

  if ((in=fopen(in_file_name,"r"))==NULL)
     {printf("  fopen failed for input");exit(1);}
  fscanf(in,"%d",&n);
  if ((out=fopen(out_file_name,"w"))==NULL)
     {printf("  fopen failed for output");exit(1);}
  seed_saved=seed;
// Allocation of core memory for an array of Instance structure objects 
// that contains flow, distance and auxiliary matrices
  ALS(pin,Instance,n+1)
  for (i=0;i<=n;i++) ALI((pin+i)->w,n+1)
  for (i=0;i<=n;i++) ALI((pin+i)->wd,n+1)
  for (i=0;i<=n;i++) ALI((pin+i)->d,n+1)
  for (i=0;i<=n;i++) ALI((pin+i)->a,n+1)
  for (i=0;i<=n;i++) ALI((pin+i)->b,n+1)
  for (i=0;i<=n;i++) ALI((pin+i)->lsum,n+1)
  for (i=0;i<=n;i++) ALI((pin+i)->ldif,n+1)
// Allocation of core memory for an array of Solution structure objects 
// that contains data used in various methods. 
// ST_COUNT is the length of performance statistics array 'perf'
  if (n>ST_COUNT) i=n; else i=ST_COUNT;
  ALS(psol,Solution,i+2)

// Data input
  for (i=1;i<=n;i++)
     {fscanf(in,"%d",&val);
      (psol+i)->l=val;(psol+i)->len=2*val;
     }
  for (i=1;i<=n;i++) for (j=1;j<=n;j++)
     {fscanf(in,"%d",&val);w(i,j)=val;wd(i,j)=val*2;
      lsum(i,j)=(psol+i)->l+(psol+j)->l;
      ldif(i,j)=(psol+i)->l-(psol+j)->l;
     }
  for (i=1;i<n;i++) for (j=i+1;j<=n;j++) if (w(i,j)!=w(j,i))
     {fprintf(out,"Symmetry violation for indices i=%2d  j=%2d \n",i,j);exit(1);}
/*fprintf(out,"<<<Facility lengths>>>\n");
for (i=1;i<=n;i++) fprintf(out," %3d",(psol+i)->l);
fprintf(out,"\n");fprintf(out,"\n");
fprintf(out,"<<<Flow matrix>>>\n");
for (i=1;i<=n;i++) {
for (j=1;j<=n;j++) fprintf(out,"%3d ",w(i,j));
fprintf(out,"\n");
}
fprintf(out,"\n");fprintf(out,"\n");*/

  start_time=clock();
// Running simulated annealing (SA) algorithm
  best_value_doubled=SA(n,PROB_LS,time_limit,time_values_opt,
      &time_to_opt,&seed,start_time,pin,psol);
  time_in_seconds=take_time(time_values,start_time);
  sol_value_doubled=get_best_value(n,pin,psol);
  if (best_value_doubled < sol_value_doubled-epsilon || best_value_doubled > sol_value_doubled+epsilon)
      fprintf(out,      "!!! some discrepancy in solution values: %8lf   %8lf\n",
      best_value_doubled,sol_value_doubled);
  best_value=best_value_doubled/2;
// Printing parameters, data characteristics and some statistics 
// regarding the performance of the algorithm
  fprintf(out,"   parameters:                                 \n");
  fprintf(out,"      COOLING_FACTOR                         = %4lf\n",COOLING_FACTOR);
  fprintf(out,"      MIN_TEMPERATURE                        = %8lf\n",MIN_TEMPERATURE);
  fprintf(out,"      tred                                   = %8ld\n",(psol+7)->perf);
  fprintf(out,"      TEMPERATURE_COEF                       = %5d\n",TEMPERATURE_COEF);
  fprintf(out,"      tlength                                = %8ld\n",(psol+8)->perf);
  fprintf(out,"      SAMPLE_SIZE                            = %5d\n",SAMPLE_SIZE);
  fprintf(out,"      PROB_LS                                = %5d\n",PROB_LS);
  fprintf(out,"      MOVE_COEF                              = %5lf\n",MOVE_COEF);
  fprintf(out,"      seed for random number generator       = %8lf\n",seed_saved);
  fprintf(out,"   number of facilities                      = %5d\n",n);
  fprintf(out,"   time limit                                = %5ld\n",time_limit);
  fprintf(out,"   number of SA starts executed              = %4ld\n",(psol+3)->perf);
  fprintf(out,"   number of improvements during SA          = %4ld\n",(psol+1)->perf);
  fprintf(out,"   last improvement at SA start no.          = %3ld\n",(psol+2)->perf);
  fprintf(out,"   value found by SA                         = %12lf\n",best_value);
  (psol+4)->perf=(long)time_to_opt;
  fprintf(out,"   time to the best solution: %d : %d : %d.%3d  (=%4ld seconds)\n",
      time_values_opt[1],time_values_opt[2],time_values_opt[3],
      time_values_opt[4],(long)time_to_opt);
  (psol+5)->perf=(long)time_in_seconds;
  fprintf(out,"   total time of SA: %d : %d : %d.%3d  (=%4ld seconds)\n",
      time_values[1],time_values[2],time_values[3],
      time_values[4],(long)time_in_seconds);
  fflush(out);

  if (pres!=NULL)
     {pres->value=best_value;
      pres->total_time=time_in_seconds;
      pres->time_to_best=time_to_opt;
      pres->characts[0]=n;
      if (pres->sol==NULL) for (i=0;i<=1;i++) ALI((pres+i)->sol,n+1)
      for (j=1;j<=n;j++) sol(0,j)=(psol+j)->bp;
     }

// Releasing the memory
  if (psol!=NULL) free(psol);
  for (i=0;i<=n;i++) if ((pin+i)->ldif!=NULL) free((pin+i)->ldif);
  for (i=0;i<=n;i++) if ((pin+i)->lsum!=NULL) free((pin+i)->lsum);
  for (i=0;i<=n;i++) if ((pin+i)->b!=NULL) free((pin+i)->b);
  for (i=0;i<=n;i++) if ((pin+i)->a!=NULL) free((pin+i)->a);
  for (i=0;i<=n;i++) if ((pin+i)->d!=NULL) free((pin+i)->d);
  for (i=0;i<=n;i++) if ((pin+i)->wd!=NULL) free((pin+i)->wd);
  for (i=0;i<=n;i++) if ((pin+i)->w!=NULL) free((pin+i)->w);
  if (pin!=NULL) free(pin);
// Closing input and output files
  fclose(out);fclose(in);
 }
