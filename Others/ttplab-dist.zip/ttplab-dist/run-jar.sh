#!/bin/sh

java -jar ./build/libs/ttplab-1.1.jar dsj1000_n999_bounded-strongly-corr_01.ttp mattp qtst-out.txt 100
