#!/bin/bash

#echo "hello world !" $1

./bins/delaunay/dct < $1
